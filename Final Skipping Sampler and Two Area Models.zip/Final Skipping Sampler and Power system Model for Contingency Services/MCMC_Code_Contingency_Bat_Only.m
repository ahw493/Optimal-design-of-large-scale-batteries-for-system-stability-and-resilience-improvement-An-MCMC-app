function MCMC_Code_Contingency_Bat_Only(adj,q,start,label_diag,sigma,NR,NN,number,Be,Be_Fault,Local_Gens,Local_Load,M,power,qa,initial_value,...
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...
                    dist_location)      %vector of battery location in the network)
                
if start ==1
      
     n = num2str(q);
     y=load(['Bat_Only_contingency_TwoArea0',n,'sd_',label_diag,'.mat'],'CONb');

     extremeevents = y.CONb.(['D',n]);
     current_dist = extremeevents(end,:);
     BAT_ROU_Sequence= y.CONb.(['BatSequence',n]);
     BAT_Nodal_Activation= y.CONb.(['BatNodeAct',n]);
     AGC_Time = y.CONb.(['AGC_Initial_Time',n]);
     Pre_Contin_Battery = y.CONb.(['Initial_Bat',n]);
     BAT_Dynamics = y.CONb.(['Bat_Dynamics',n]);
    
else
     current_dist = initial_value;
     extremeevents=[];
     BAT_Nodal_Activation= [];
     BAT_ROU_Sequence = [];
     AGC_Time = [];
     Pre_Contin_Battery = [];
     BAT_Dynamics = {};
     
     
end

jj = 0;
aa = adj;
for i = 1:number

limitcounter = 1;

prop_dist = mvnrnd(current_dist,aa*sigma);
proposeddirection = prop_dist - current_dist;
unitdistance = proposeddirection/norm(proposeddirection);
k = 6;

while limitcounter <= k
    
    chisqr = chi2rnd(NR,1);
    proposeddistance = ((proposeddirection*inv(aa*sigma)*proposeddirection')^-0.5)*sqrt(chisqr);
    prop_dist = prop_dist + (limitcounter >1)*proposeddistance*unitdistance;
    
    if (sum(prop_dist > 0.4) || sum(prop_dist < -0.4) )>0
        Region = 0;
        break
    end
    
r = rand(1,7);

         [UFLS_Bat,...         % BINARY: test for under frequency load shedding during simulation
          BAT_sequence,...          % 20 X 16 array of protection system activations
          BAT_NodalFailure,...      % 4 X 6 array of protection system ativations at each node
          Time_to_AGC,...       %this is the time until the next agc signal
          Initial_Battery...    % this is the initial battery output
 ] = Two_Area_Battery_Model(...
                    prop_dist,...         % this is the disturbance vector from the MCMC
                    Be,...          % normal b matrix
                    Be_Fault,...    %faulted B-matrix in case of line trip
                    M,...           % generator/motor inertia
                    Local_Gens,...          % location of generators 
                    Local_Load,...          % location of loads
                    power,...          % pre-contingency power vector
                    NN,...            %number of nodes
                    NR,...            %number of loads
                    qa,...            %initial conditions for dynamical system
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...   %vector of battery location in the network
                    [55,65],...  %nominal frequency range
                    r,...                %random values for agc time and intial battery output
                    dist_location) ;
                            
    if  UFLS_Bat>0 

         Region = 1;
        break
    else
        Region = 0;
    end
    limitcounter = limitcounter+1;
end

accept = mvnpdf(prop_dist',zeros(NR,1),sigma)*Region/mvnpdf(current_dist',zeros(NR,1),sigma);

if accept > rand()
    
    jj = jj+1;
   
    current_dist = prop_dist;
    extremeevents(end+1,:) = prop_dist;
    BAT_ROU_Sequence(:,:,end+1) = BAT_sequence;
    BAT_Nodal_Activation(:,:,end+1) = BAT_NodalFailure;
    %BAT_Dynamics{end+1} = BAT_Dynamics_TFVGBR;
    AGC_Time(end+1) = Time_to_AGC;
    Pre_Contin_Battery(:,end+1) = Initial_Battery;

end
    rate = jj/i;

end
[q rate]
save_MCMC_Contingency_bat_only(q,...
        extremeevents,...
        BAT_ROU_Sequence,...
        BAT_Nodal_Activation,...
        BAT_Dynamics,...
        AGC_Time,...       %this is the time until the next agc signal
        Pre_Contin_Battery,...  
        label_diag...
        );
end
