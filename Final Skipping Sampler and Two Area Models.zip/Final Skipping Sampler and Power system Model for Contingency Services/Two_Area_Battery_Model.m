function [UFLS_Test,...         % BINARY: test for under frequency load shedding during simulation  extreme_freq,...
          sequence,...          % 20 X 16 array of protection system activations
          nodalFailure,...      % 4 X 6 array of protection system ativations at each node  Dynamics_TFVGBR,...   %list of Frequency, Voltage Governor Battery and ROCOF dynamics 
          Time_to_AGC,...       %this is the time until the next agc signal
          Initial_Battery...    % this is the initial battery output
 ] = Two_Area_Battery_Model(...
                    inp,...         % this is the disturbance vector from the MCMC
                    be,...          % normal b matrix
                    Be_Fault,...    %faulted B-matrix in case of line trip
                    m,...           % generator/motor inertia
                    LG,...          % location of generators 
                    LL,...          % location of loads
                    pw,...          % pre-contingency power vector
                    nn,...            %number of nodes
                    nr,...            %number of loads
                    qa,...            %initial conditions for dynamical system
                    batcap,...        %vector of battery maximum power outputs/inputs
                    Bat_node_loc,...   %vector of battery location in the network
                    nom_freq_range,...  %nominal frequency range
                    r,...                %random values for agc time and intial battery output
                    dist_location...        %a 1 X 6 vector for the location of the disturbances: either the load or generators nodes
                    ) 
% clear all 
global Time_List Rocof_List volt_list RateBatPow u power regime begin Local_Gens Local_Load gen_trip load_shed_event_tally ...
elec rocof maxfreq Rocof_Thres Ulim Llim FD FN UagcSOC LagcSOC UlimSOC LlimSOC...
numbat Uagc Lagc NN M D Be mem Pb agc B0 Pbat connector_power con_relay ...
bias line_trip nextAGCsignal AGCinterval batteryperformance load_shed_schd vdeadband...
minN maxN lse_tally connect_relay_delay rocof_movingaverage BatLoc freq_delay rocof_delay...
lse freq_list freq_movavg agc_bat_out emergency deadband droop_u droop_d gen_power rad_to_hertz loads line_power_limit

% tic
% 
% load('Two_Area_Inputs_Cap_RLoad_RGen.mat')
% load('Two_Area_initial2.mat')
% batcap = [2 1  2]*0;
% BatLoc = [1 2 3 ];
% nom_freq_range = [59 60];

Pb = @() passing;
deadband = @(gov,NN,FD) fdband(gov,NN,FD);
vdeadband = @(gov,NN) vdband(gov, NN);
elec =  @(v,NN,b) (v(2*NN+1:3*NN).*(b.*sin(v(1:NN)-v(1:NN)'))*v(2*NN+1:3*NN));
rocof = @(gov,NN,M,D,u,power,elec,Be,Pb,mn,mx,FD,Local_Gens,loads) (M)\(-D*gov(NN+1:2*NN)+...
    max(mn',min((Local_Gens'.*(gov(6*NN+1:7*NN)) + power'),mx')) + Pb()' - loads'+ u' - elec(gov,NN,Be));

j2 = @(gov,u,D,M,NN,X,Eref,Be,T,power,elec,...
    Pb,aq,govdroop,FD,GT,Te,Ta,Ts,Ke,Ka,Ks,mn,mx,shutoff,Local_Gens,loads) [
    
    gov(NN+1:2*NN);                                                                 % PHASE ANGLES
    rocof(gov,NN,M,D,u,power,elec,Be,Pb,mn,mx,FD,Local_Gens,loads);                                     % RATE OF CHANGE OF FREQUENCY (SWING EQN)
    (1./T).*(shutoff'.*( Eref' - aq'.*gov(5*NN+1:6*NN) ) - gov(2*NN+1:3*NN) + X.*(Be.*cos(gov(1:NN)-gov(1:NN)'))*gov(2*NN+1:3*NN)) ;  % TERMINAL VOLTAGE EQUATION 2*NN+1:3*NN
    vdeadband(gov,NN).*shutoff'.*aq'.*(1./Ts).*(Ks*(Eref' - gov(2*NN+1:3*NN)) - gov(3*NN+1:4*NN));                              % AVR: SENSOR 
    vdeadband(gov,NN).*shutoff'.*aq'.*(1./Ta).*(Ka*( -gov(3*NN+1:4*NN)) - gov(4*NN+1:5*NN));                     % AVR AMPLIFIER
    vdeadband(gov,NN).*shutoff'.*aq'.*(1./Te).*(Ke*gov(4*NN+1:5*NN) - gov(5*NN+1:6*NN));                              % AVR EXCITER
    deadband(gov,NN,FD).*shutoff'.*aq'.*(-govdroop'.*gov(NN+1:2*NN)); 
     ]; 
%______________________________________________________________________________________________________________________________

%------------------------------------------------------------------INPUT VARIABLES-----------------------------------------------------
Be = be; M=m;Local_Gens = LG;Local_Load = LL;power = pw;NN = nn; NR=nr;

BatLoc = Bat_node_loc;
rad_to_hertz = 2*pi;
loads = [1 1 0.5 0.5 -power(5:6)];
pre_dist_loads = loads;
power(5:6) =0;
power(1:4) = power(1:4) + [1 1 0.5 0.5];
D = 2/(2*pi*60); 
dM = diag(M(1:4,1:4));      %dampening coefficients for each node
X = (1.8-0.3)*(100/900)*(20/230)^2;                              %resistance
Eref = ones(1,NN)*1;
T = 8;

%DISTURBANCE VECTOR........................................................

u = disturbance(inp,NN,dist_location).*[power(1:4) loads(5:6)] ;           %disturbance vector (at the generators right now) disturbance(-0.5+rand(1,4),NN).*power ;            %disturbance vector (at the generators right now)

%INPUTS FOR PROTECTION SYSTEMS.............................................
connector_power = 4;
connect_relay_delay = 4;
line_power_limit = 5.1; 
maxfreq = 2;                                        %max frequency limit for OFGS 
Rocof_Thres = 3;                                       %abs rocof threshold
freq_delay  = 2;
rocof_delay = 1;
maxN = Local_Gens*9 + Local_Load*0;
minN = Local_Gens*0 + Local_Load*-20;
load_shed_schd = [ -1 -1.5 -2 -2.5 -3 ];  

shutoff = ones(1,NN);      %THIS IS A BINARY VARIABLE: INTIAL VALUE IS 1 AT ALL NODES. ...
                           % WHEN A GENERATOR DISCONNECTS DUE TO ROCOF OR
                           % OFGS, IT SETS FIELD VOLTAGE AT THAT NODE TO ZERO; GOVERNOR
                           % DIFFERENTIAL EQUATION AND OUTPUTS TO ZERO; AND
                           % THE AVR SENSOR, EXCITER AND AMPLIFIER OUTPUTS
                           % AND DIFFERENTIAL EQUATIONS TO ZERO.
                   
%.........................................................................

%governor model............................................................

aq = Local_Gens;             % places governors at generators
govdroop = 2;
GT = 0.25;
%...........................................................................

%AGC SETTINGS AND PARAMETERS..............................................

agclim = 0.5;                                           %abs limit for battery power to be provided by AGC
AGCinterval = 4;                                      %time interval for the impulse signal for AGC
mem = 0;                                                %required to memorize the previous time step
agc = 0;                                                %agc indicator: 0: AGC off; 1: AGC ON
nextAGCsignal = r(1)*AGCinterval;
Time_to_AGC = nextAGCsignal;

%BATTERY PARAMETERS AS INPUTS..............................................
RateBatPow = zeros(1,6);
RateBatPow(BatLoc) = batcap;                                  %battery capabilility
B0 = agclim*(-0.05 + 0.1*r(2:end)).*[0 0 0 0 4 4];%RateBatPow;            %initial battery operating point
Initial_Battery = B0;
agc_bat_out = B0(BatLoc);
Ulim =   RateBatPow;                                          %upper limit of the capability of the battery                           
Llim = - RateBatPow;                                         %lower limit of the capability of the battery
numbat = sum(Local_Load);                                   %number of batteries in the network (required for the AGC)
FD = 0.05;                                                  %deadband frequency range
FN = 0.15;                                                   %maximum AGC limit
Fmax = 1;
Uagc = agclim*[0 0 0 0 4 4];%RateBatPow;                                   %upper AGC power limit
Lagc = -agclim*[0 0 0 0 4 4];%RateBatPow;                                  %lower limit for battery power commanded by AGC

droop_u = (RateBatPow(BatLoc)-agc_bat_out)./(Fmax-FN);                                             %required to calculate battery droop response    
droop_d = (RateBatPow(BatLoc)+agc_bat_out)./(Fmax-FN);

Pbat = B0;                                                  %CORrrectedBattery Power following the AGC signal
batteryperformance = [0 B0];
bias = 1.5;
emergency = zeros(1,NN);

%STATE OF CHARGE %VARIABLES................................................

% BatteryCapacity = 55;                                       %total battery capacity
% SOC = rand(1,NN)*BatteryCapacity;                           %initial state of charge of each battery
UagcSOC = Uagc(BatLoc);LagcSOC = Lagc(BatLoc);UlimSOC = Ulim(BatLoc);LlimSOC = Llim(BatLoc);    %initializing the limits under State of Charge

%..........................................................................

%AVR MODEL PARAMETERS......................................................

Te = 1;
Ke = 10;
Ta = 0.1;
Ka = 10;
Ts = 0.05;
Ks = 1;

%INITIALISING LIST VARIABLES...............................................

gen_trip = ~Local_Gens;
line_trip = 0;
Time_List = [];  
Rocof_List = [];
volt_list = [];
freq_list =[];
rocof_tally = zeros(1,NN);
OFGS_tally = zeros(1,NN);
UFLS_tally = zeros(1,NN);
load_shed_event_tally = zeros(1,NN);
lse_tally = zeros(1,NN);
con_relay = 0;

%INITIAL PARAMETERS FOR THE ODE SOLVER

unstable =  8;
points2 =  20;
dt2 = unstable/points2;
interval = 0:dt2:unstable + 0.5;
begin = 0;
initial = qa; 
record = [];
options = odeset('Events',@ProtectionTrip,'AbsTol',1e-5);
load_shed = 0.15*loads; %load shed amount at each node
sequence = zeros(31,20);

j=0;

% Be = Be_Fault;
% line_trip = 1;
% l=1;
% power(l) = 0;%.85*power(5);
% aq(l) = 0;
% gen_trip(l) = 1;
% dM(l) = 0;
% loads =  0.9*loads;

M = sum(dM);

while begin < unstable
 
j = j+1;
regime = 1; 
[td,bat,~,~,failuretype] = ode45(@(td,bat) j2(bat,u,D,M,NN,X,Eref,Be,T,power,elec,Pb,aq,govdroop,FD,GT,Te,Ta,Ts,Ke,Ka,Ks,minN,maxN,shutoff,Local_Gens,loads),interval,initial,options);
[rocof_loc,gen_shed_loc,load_shed_event,con_relay] = classify_failure(failuretype,NN);          % this functions classifies each type of failure and its location and saves the result in the ooutput variables
record = [record(1:end,:); td bat(:,[NN+1:3*NN,6*NN+1:7*NN])];
sequence(j,:) = [td(end), rocof_loc,gen_shed_loc,load_shed_event,con_relay];
gen_trip = gen_trip + rocof_loc + gen_shed_loc; % this is a variable used to record the number of generator trips
line_trip  = line_trip + con_relay ;
rocof_tally = rocof_tally + rocof_loc;
OFGS_tally  = OFGS_tally  + gen_shed_loc;
UFLS_tally = UFLS_tally + load_shed_event;
lse_tally = lse_tally + load_shed_event;
power(rocof_loc|gen_shed_loc) = 0;               %turns the power off at generators which experienced rocof or ofgs events

if con_relay == 1
    Be = Be_Fault;
    d_M([1,2,5]) = sum(dM(1:2));   %if generator is shed AFTER a line trip, calculate new inertia for area 1
    d_M([3,4,6]) = sum(dM(3:4));   %if generator is shed AFTER a line trip, calculate new inertia for area 2
    M = diag(d_M);               %M is now a 6 X 6 matrix
    D_mat([1 2 5]) = 2*sum(loads([1 2 5]))/sum(pre_dist_loads([1 2 5])); %D for area 1 after line trip
    D_mat([3 4 6]) = 2*sum(loads([3 4 6]))/sum(pre_dist_loads([3 4 6]));  
    D = diag(D_mat)./(2*pi*60);
end

if sum(rocof_loc+gen_shed_loc)>0        %tests for generation shedding event
    dM(rocof_loc|gen_shed_loc) = 0.04;  %set the inertia constant at the lost generator to approx 0;

    if line_trip > 0
            d_M([1,2,5]) = sum(dM(1:2));   %if generator is shed AFTER a line trip, calculate new inertia for area 1
            d_M([3,4,6]) = sum(dM(3:4));   %if generator is shed AFTER a line trip, calculate new inertia for area 2
            M = diag(d_M);               %M is now a 6 X 6 matrix
    else     
        M = sum(dM);                    % if there is no line trip, M is the sum of the 4 inertias
    end
end

if sum(load_shed_event)>0
loads = loads - load_shed_event.*load_shed;   %new load after load shed event

    if line_trip>0
         D_mat([1 2 5]) = 2*sum(loads([1 2 5]))/sum(pre_dist_loads([1 2 5])); %D for area 1 after line trip
         D_mat([3 4 6]) = 2*sum(loads([3 4 6]))/sum(pre_dist_loads([3 4 6]));  
         D = diag(D_mat)./(2*pi*60);
    else
         D = D*(sum(loads)/sum(pre_dist_loads)); 
    end
end

shutoff(rocof_loc|gen_shed_loc) = 0;
initial = [bat(1:3*NN) [shutoff shutoff shutoff shutoff].*bat(end,3*NN+1:end)];
begin =  td(end) + 0.001;
interval = [begin,interval(interval>begin)];

end

nodalFailure = [rocof_tally;OFGS_tally;UFLS_tally; sum([rocof_tally;OFGS_tally;UFLS_tally],1)];
sequence = sequence(1:end-1,:);
UFLS_Test = sum(UFLS_tally,'all')>0;
%battery_TS = interp1(batteryperformance(:,1),batteryperformance(:,2:end),record(:,1));    %battery output for time steps above (interpolated)
% Mov_RoCoF_TS = interp1(Time_List,rocof_movingaverage,record(:,1)); %rocof for time steps above (interpolated)
% Mov_Freq_TS = interp1(Time_List,freq_movavg,record(:,1)); 
% Dynamics_TFVGBR  = [record(:,1),Mov_Freq_TS+60,record(:,NN+2:end),battery_TS, Mov_RoCoF_TS];
% extreme_freq = [( (min(Dynamics_TFVGBR(:,2:NN+1),[],'all')<nom_freq_range(1)) | (max(Dynamics_TFVGBR(:,2:NN+1),[],'all')>nom_freq_range(2))  )>0, max(Dynamics_TFVGBR(:,2:NN+1),[],'all'), min(Dynamics_TFVGBR(:,2:NN+1),[],'all')];

% toc
%
end


function[position,term,direction]= ProtectionTrip(t,sol)

global NN gen_trip Local_Gens  power_change line_power_limit...
    maxfreq Rocof_Thres lse_tally load_shed_schd Local_Load line_trip 

gen_shed =  @(s) (s.*Local_Gens)<maxfreq;
load_shed2 = @(s,mf) (s)>mf;      % for load frequency activated UFLS
% load_shed2 = @(s,mf) s>mf;        % for generator frequency activated UFLS

Construct_List(t,sol);               %launches the construct_list function which lists the time and rocof values from each step

[adjma, ma_freq]   = MovAvg();           %calculates the 1s moving average for ROCOF
% Area_avg_freqs = [mean(ma_freq(1:2)) mean(ma_freq(3:4))];
mf = load_shed_schd(lse_tally+1);
% load_shed2(Area_avg_freqs,mf);

line_freq = sum(abs(ma_freq(5:6))>2);
ICT = power_change<line_power_limit || line_freq<1; %test for the line tripping

position = [((adjma)<Rocof_Thres)+gen_trip, gen_shed(ma_freq)+gen_trip,load_shed2(ma_freq,mf)+(lse_tally>=4),ICT+line_trip]';
term     = [ones(1,NN),ones(1,NN),ones(1,NN) 1]';
direction = []; 

end

function [AdjMA,Adj_FMA] = MovAvg()

   global begin Local_Gens  Time_List Rocof_List rocof_delay...
          freq_list freq_delay rocof_movingaverage freq_movavg
   
window_rocof = Time_List(end)>=rocof_delay;
window_freq = Time_List(end)>=freq_delay;
rocof_movingaverage = movmean(Rocof_List,[rocof_delay,0],1,'SamplePoints',Time_List,'Endpoints','shrink');

freq_movavg = movmean(freq_list,[freq_delay,0],1,'SamplePoints',Time_List,'Endpoints','shrink');
AdjMA   = (rocof_movingaverage(end,:).*Local_Gens)*window_rocof*(Time_List(end)>begin); %captures the moving average of rocof
Adj_FMA = freq_movavg(end,:)*window_freq*(Time_List(end)>begin); %captures the moving average of rocof

% mov_avg_rocof_list = rocof_movingaverage;

end

function Construct_List(t,sol)

global Time_List Rocof_List u power regime rocof...
    elec Pb NN M D Be minN maxN freq_list Local_Gens connector_power connect_relay_delay...
    FD power_change con_relay volt_list gen_power rad_to_hertz loads load_power

if t > 0 && t <= Time_List(end) 
   regime = 0;   
elseif regime == 0 && (t-Time_List(end))>0.0005
    regime = 1;
end

if regime == 0 
    
   Time_List(end) = t;
   Rocof_List(end,:) = abs(rocof(sol,NN,M,D,u,power,elec,Be,Pb,minN,maxN,FD,Local_Gens,loads))'/rad_to_hertz;
   freq_list(end,:) = sol(NN+1:2*NN)'/rad_to_hertz;
   connector_power(end) = abs(sol(2*NN+5)*sol(3*NN)*Be(5,6)*sin(sol(5)-sol(6)));
   power_change = (connector_power(end) - connector_power(1))*(t>connect_relay_delay);

else
   Time_List  = [Time_List; t];
   Rocof_List = [Rocof_List; abs(rocof(sol,NN,M,D,u,power,elec,Be,Pb,minN,maxN,FD,Local_Gens,loads))'/rad_to_hertz];
   freq_list =  [freq_list; sol(NN+1:2*NN)'/rad_to_hertz];
   volt_list = [volt_list;sol(2*NN+1:3*NN)'];

   if con_relay<1
   connector_power = [connector_power; abs(sol(2*NN+5)*sol(3*NN)*Be(5,6)*sin(sol(5)-sol(6)))];
   
   if t>connect_relay_delay
       connector_power(1) = [];
   end
   power_change = (connector_power(end) - connector_power(1))*(t>connect_relay_delay);
   end
end

if regime == 1 && length(Time_List)>1
BatteryModel(sol);                         %passes t and sol to the AGC function
end

end

function [rocof_loc,gen_shed_loc,load_shed_event,conn_relay_trip] = classify_failure(failuretype,NN)

rocof_loc = zeros(1,NN); conn_relay_trip = 0; gen_shed_loc = zeros(1,NN);load_shed_event=zeros(1,NN);
rocof_loc(failuretype(failuretype<=NN))=1;
gen_shed_loc(failuretype(failuretype >= (NN+1) & failuretype <= 2*NN)-NN) =1;
load_shed_event(failuretype(failuretype>2*NN & failuretype <19)-2*NN) = 1;
% lsetotal = load_shed_event([5,6]);
conn_relay_trip(max(failuretype)==19) =1;

if sum(rocof_loc+gen_shed_loc>1)>0
    rocof_loc((rocof_loc+gen_shed_loc)>1)=0;
end


end

function BatteryModel(sol)

global FD FN B0 nextAGCsignal AGCinterval E_FCAS rad_to_hertz...
       NN Time_List agc Pbat BatLoc agc_bat_out R_FCAS batteryperformance


freq = sol(NN+1:2*NN)'/rad_to_hertz;         % frequency deviation at time t
abs_freq = abs(freq);           % absolute value of the frequency deviation

E_FCAS = abs_freq(BatLoc)>=FN;  % test to see if frequency deviation is in the emergency band

R_FCAS = abs_freq(BatLoc)<FN  ; % indicates whethere frequency deviation at battery nodes are within agc command range (1)

%AGC Signal and AGC Command

if Time_List(end) >= nextAGCsignal
%     fprintf('signal now')
    nextAGCsignal = nextAGCsignal + AGCinterval; %sets the next time agc signal    
    agc = mean(freq)>FD;  %measures whether the average frequency across the network requires agc action - (1). Else 0
    agc_ref_freq = mean(freq);    % signal to be sent to ALL batteries 
    
   if agc>0 %frequency deviation is in the response range
       agc_bat_out = AGCBat(agc_ref_freq); %battery power under the agc command 
   else
       agc_bat_out = B0(BatLoc); % battery power is set to pre disturbance power when agc is 0. 
   end   
end

Pbat(BatLoc) =  EmergencyBat(freq,E_FCAS) + agc*(~E_FCAS).*agc_bat_out + (~agc)*(~E_FCAS).*B0(BatLoc);
batteryperformance = [batteryperformance;Time_List(end) Pbat];



end

function Ebat = EmergencyBat(f,emergency) 

global UlimSOC LlimSOC droop_u droop_d B0 BatLoc FN
    
    local_bat_freq = f(BatLoc);
    ad_f = abs(local_bat_freq) - FN; %adjusted frequency by removing FN
    n_f = ad_f.*sign(local_bat_freq); %adjusted frequency with original sign
    ud = sign(local_bat_freq)>0;
    droop = droop_u.*(~ud) + droop_d.*(ud);
    Eb = (-droop.*(n_f) + B0(BatLoc)).*emergency; %emergency battery response on top of initial battery point
    Ebat = Eb.*(Eb>=LlimSOC & Eb<=UlimSOC) + LlimSOC.*(Eb<LlimSOC) + UlimSOC.*(Eb>UlimSOC); %with limits

end

function Abat = AGCBat(f)  

   global UagcSOC LagcSOC bias B0 BatLoc
   
   Agcbat = -bias*f + B0(BatLoc);
   Abat =  Agcbat.*(Agcbat>=LagcSOC & Agcbat<=UagcSOC) + LagcSOC.*(Agcbat<LagcSOC) + UagcSOC.*(Agcbat>UagcSOC);
   
end

function w = fdband(gov,NN,FD)

global rad_to_hertz
w = abs(gov(NN+1:2*NN)/rad_to_hertz)>FD;

end

function vd = vdband(gov,NN)
vd = abs(1 - gov(2*NN+1:3*NN)) > 0.05;
end

function v = passing()
global Pbat
v = Pbat;
end

function u = disturbance(dist,NN,dist_loc)

u = zeros(1,NN);
u(dist_loc) = dist;
end
