function frequency_area_plots_cluster_cov

% load('Two_Area_Inputs_Cap_RLoad_RGen.mat')

exten = ['/data/home/ahw493/transaction A/varying covariance load battery all dist relative to load/charts'];
% exten = ['C:\Users\Maldon\OneDrive - Queen Mary, University of London\Matlab Files\full battery models\Gaussian MCMC Bat\TWO AREA MODELS\TwoAreaModels\Comparative Two Area MCMC\Load Battery Simulations\cluster results\charts'];

power = [7.8350    7.8350    7.3350    7.3350    9.6700   17.6700];

k = 0;

sig2 = @(stdv,corr,ND)ones(ND,ND)*(corr*stdv)+diag(ones(1,ND)*(stdv-corr*stdv));

kk = ones(1,2);
bat_list = 0:1:10;
Disturbance_Location = 3;

for i = 1:length(bat_list)
bat_cap_list{i} = kk*bat_list(i);
end

st_dev = 0.003;
sig_off_diag = [0 0.2 0.4 0.6 0.8];

u=0;
for i = 1:length(sig_off_diag)
    for j = 1:length(bat_cap_list)
        u = u +1;
        pairs{u} = [u, sig_off_diag(i), bat_cap_list{j}];
    end
end

for j = 1:length(sig_off_diag)

for i = 1:length(bat_cap_list)

k = k+1;
    
if Disturbance_Location==1
    NR = 4;
    label = ['Gen_Dist'];
elseif Disturbance_Location ==2
    NR = 2;
    label = ['Load_Dist'];
else
    NR = 6;
    label = ['Full_Dist'];
end

max_battery = pairs{k}(3:end);                %this should be the same dimension as battery_location and outlines the size of the battery at each node in per unit form
off_diag = pairs{k}(2);
sigma = sig2(st_dev,off_diag,NR);
n1 = num2str(max_battery(1)*100);
cova = num2str(sigma(1,2)*10);        

    
y=load(['covariance_',cova,'_',n1,'MW_BatFreq_Reg',label,'.mat'],'FRb');

     extremeevents = y.FRb.(['D',n1]);
     BAT_Dynamics = y.FRb.(['Bat_Dynamics',n1]);
     
for ii = 1:length(BAT_Dynamics)
freq = BAT_Dynamics{ii}(:,2:7);
of = freq - 60.15;
of(of<-0.01) = 0;
uf = freq - 59.85;
uf(uf>0.01) = 0;
t = BAT_Dynamics{ii}(:,1);
Area_Node_Raw(ii,:) = (trapz(t,abs(of),1) + trapz(t,abs(uf),1));

end

mean_system_dist(j,i) = mean(sum(abs(extremeevents),2));%abs(mean(sum(extremeevents,2)));%mean(abs(extremeevents),'all');

system_mean_area_raw(j,i) = mean(Area_Node_Raw,'all','omitNaN');
    system_mean_FEA_per_dist(j,i) = system_mean_area_raw(j,i)./mean(sum(abs(extremeevents),2));%mean(abs(extremeevents),'all');

end

end

f.a1 = figure('Units','normalized');
set(f.a1,'Units','Normalized','OuterPosition',[0 0 1 1]);
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

f.a2 = figure('Units','normalized');
set(f.a2,'Units','Normalized','OuterPosition',[0 0 1 1]);
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

f.a3 = figure('Units','normalized');
set(f.a3,'Units','Normalized','OuterPosition',[0 0 1 1]);
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

figure(f.a1)
subplot(1,3,1)
plot(bat_list,system_mean_area_raw,'LineWidth',2)
set(gca,'linewidth',2,'FontSize',14);
box on
grid on
xlabel('$Battery\ Capacity,\ MW$');   %xlabel('$xlabel$','Interpreter','latex');
ylabel('$Average\ FEA$');   %ylabel('$ylabel$','Interpreter','latex');  
%title('$Average\ FEA$')
set(legend,'color','none')
legend({'0', '0.2' ,'0.4','0.6', '0.8', '0.99'},'location','best');
title(legend,'\alpha','interpreter','tex')
xticks(0:1:10)

subplot(1,3,2)
plot(bat_list,mean_system_dist,'LineWidth',2)
set(gca,'linewidth',2,'FontSize',14);
box on
grid on
xlabel('$Battery\ Capacity,\ MW$');   %xlabel('$xlabel$','Interpreter','latex');
ylabel('$Average\ Disturbance\ Magnitude$');   %ylabel('$ylabel$','Interpreter','latex');  
%title('$Average\ Disturbance\ Magnitude$')
%set(legend,'color','none')
%legend({'0', '0.2' ,'0.4','0.6', '0.8', '0.99'},'location','best');
%title(legend,'\alpha','interpreter','tex')
xticks(0:1:10)

subplot(1,3,3)
plot(bat_list,system_mean_FEA_per_dist/100,'LineWidth',2)
set(gca,'linewidth',2,'FontSize',14);
box on
grid on
xlabel('$Battery\ Capacity,\ MW$');   %xlabel('$xlabel$','Interpreter','latex');
ylabel('$Normalized FEA$');   %ylabel('$ylabel$','Interpreter','latex');  
%title({'$Average\ System\ FEA$','$Per\ MW\ Disturbance$'});
%legend({'0', '0.2' ,'0.4','0.6', '0.8', '0.99'},'location','northeastoutside');
%set(legend,'color','none')
%title(legend,'\alpha','interpreter','tex')
xticks(0:1:10)

sss = ['FINAL 3a PAPER FEA DIST FEA per DIST.jpg'];
spdf = ['FINAL 3a PAPER FEA DIST FEA per DIST'];
saveas(f.a1,sss);%[exten,'/',sss]);
saveas(f.a1,spdf);%[exten,'/',spdf]);
close(f.a1);

figure(f.a2)
subplot(1,2,1)
plot(bat_list,mean_system_dist,'LineWidth',2)
set(gca,'linewidth',2,'FontSize',14);
box on
grid on
xlabel('$Battery\ Capacity,\ MW$');   %xlabel('$xlabel$','Interpreter','latex');
ylabel('$Average\ Disturbance\ Magnitude$');   %ylabel('$ylabel$','Interpreter','latex');  
%title('$Average\ Disturbance\ Magnitude$')
set(legend,'color','none')
legend({'0', '0.2' ,'0.4','0.6', '0.8', '0.99'},'location','best');
title(legend,'\alpha','interpreter','tex')
xticks(0:1:10)


subplot(1,2,2)
plot(bat_list,system_mean_FEA_per_dist/100,'LineWidth',2)
set(gca,'linewidth',2,'FontSize',14);
box on
grid on
xlabel('$Battery\ Capacity,\ MW$');   %xlabel('$xlabel$','Interpreter','latex');
ylabel('$Normalized\ FEA$');   %ylabel('$ylabel$','Interpreter','latex');  
%title('$Avg.\ System\ FEA\ Per\ MW\ Disturbance$');
%legend({'0', '0.2' ,'0.4','0.6', '0.8', '0.99'},'location','northeastoutside');
%set(legend,'color','none')
%title(legend,'\alpha','interpreter','tex')
xticks(0:1:10)

ssss = ['FINAL  2a PAPER Dist and FEA vs Battery for different covariances.jpg'];
sspdf = ['FINAL  2a PAPER Dist and FEA vs Battery for different covariances'];
saveas(f.a2,ssss);%[exten,'/',sspdf]);
saveas(f.a2,sspdf);%[exten,'/',ssss]);
 close(f.a2);

figure(f.a3)
plot(bat_list,system_mean_FEA_per_dist/100,'LineWidth',2)
set(gca,'linewidth',2,'FontSize',14);
box on
grid on
xlabel('$Battery\ Capacity ,\ MW$');   %xlabel('$xlabel$','Interpreter','latex');
ylabel('$Normalized\ FEA$');   %ylabel('$ylabel$','Interpreter','latex');  
title('$Avg.\ System\ FEA\ Per\ MW\ Disturbance$');
legend({'0', '0.2' ,'0.4','0.6', '0.8', '0.99'},'location','eastoutside');
set(legend,'color','none')
title(legend,'\alpha','interpreter','tex')
xticks(0:1:10)

s = ['FINAL 1a PAPER FEA vs Battery for different covariances .jpg'];
spdf2 = ['FINAL 1a PAPER FEA vs Battery for different covariances'];
saveas(f.a3,s);%[exten,'/',s]);
saveas(f.a3,spdf2);%[exten,'/',spdf2]);
close(f.a3);

 end