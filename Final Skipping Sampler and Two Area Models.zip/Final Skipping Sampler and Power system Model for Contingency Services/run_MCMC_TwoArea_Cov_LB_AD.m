clear all
tic

load('Two_Area_Inputs_Cap_RLoad_RGen.mat')
load('Two_Area_initial.mat')

start = 0;
number = 10000;

sig2 = @(stdv,corr,ND)ones(ND,ND)*(corr*stdv)+diag(ones(1,ND)*(stdv-corr*stdv));

kk = ones(1,2);
bat_list = [0:1:10];

for i = 1:length(bat_list)
bat_cap_list{i} = kk*bat_list(i);
end

st_dev = 0.003;
sig_off_diag = 0.2;
u=0;

for i = 1:length(sig_off_diag)   
    for j = 1:length(bat_cap_list)
        u = u +1;
        pairs{u} = [u, sig_off_diag(i), bat_cap_list{j}];
    end 
end



%_INPUTS_________________________________________________________________________________________________________

battery_location = [5 6];           %use vector [1 2 3 4] for generator batteries. Else, use [5 6] for load batteries. 
                                     
type = 2 ;                   % there are 4 types of analysis:
                                     % 1: Comparative Contingency Analysis-conditions on a disturbance causing at least 1 UFLS in the no battery model and none in the battery model
                                     % 2: Battery Only Contingency Analysis- conditions on a disturbance causing at least 1 UFLS  in the battery model only
                                     % 3: Comparative Frequency Regulation Analysis-conditions on a disturbance causing a frequency deviation outside the nominal operating band in the no battery model and none in the battery model
                                     % 4: Battery Only Frequency Regulation Analysis-conditions on a disturbance causing a frequency deviation outside the nominal operating band in battery model only

nom_freq_range = [59.85, 60.15];     % this is the nominal frequency band for the frequency regulation MCMC

Disturbance_Location = 3;            % 1: disturbances at generators 
                                     % 2: disturbance at loads
                                     % 3: disturbance at both lods and  generators
%____________________________________________________________________________________________________________________

for qq = 1:length(pairs)

qq  
adj = 0.1;              			%ew(qqq,3);
max_battery = pairs{qq}(3:end);                %this should be the same dimension as battery_location and outlines the size of the battery at each node in per unit form
off_diag = pairs{qq}(2);
if Disturbance_Location==1
    NR = 4;
    dist_location = Local_Gens;
    label = ['Gen_Dist'];
elseif Disturbance_Location ==2
    NR = 2;
    dist_location = Local_Load;
    label = ['Load_Dist'];
else
    NR = 6;
    dist_location = logical(Local_Load+Local_Gens);
    label = ['Full_Dist'];
end

mcmc_initial_value = ones(1,NR).*[0.37 0.37 -0.37 -0.38 -0.385 -0.38];
sigma = sig2(st_dev,off_diag,NR);

  
  %  position = pairs{qq}(1:2);

    if type ==1
                MCMC_Code_Contingency(qq,start,label,sigma,NR,NN,number,Be,Be_Fault,Local_Gens,Local_Load,M,power,qa,mcmc_initial_value,...
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...
                    dist_location) 
                               
    elseif type ==2
               MCMC_Code_Contingency_Bat_Only(adj,qq,start,label,sigma,NR,NN,number,Be,Be_Fault,Local_Gens,Local_Load,M,power,qa,mcmc_initial_value,...
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...
                    dist_location)  
                
    elseif type ==3
                MCMC_Code_Freq_Reg(qq,start,label,sigma,NR,NN,number,Be,Be_Fault,Local_Gens,Local_Load,M,power,qa,mcmc_initial_value,...
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...   %vector of battery location in the network
                    nom_freq_range,...
                    dist_location)
    else           
                MCMC_Code_Freq_Reg_Bat_Only(qq,start,label,sigma,NR,NN,number,Be,Be_Fault,Local_Gens,Local_Load,M,power,qa,mcmc_initial_value,...
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...   %vector of battery location in the network
                    nom_freq_range,...
                    dist_location) 
    end
    

end 
toc